package com.el.mkoba;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class SlideAdpter extends PagerAdapter {

    Context mContext;
    LayoutInflater layoutInflater;

    public SlideAdpter(Context context) {
        mContext = context;
    }

    public int[] slideIamage = {

            R.drawable.buyer,
            R.drawable.safepay,
            R.drawable.account
    };

    public String[] slideHeadings = {
            "M-koba",
            "Safe payment",
            "Registration"
    };
    public String[] slideDesc = {
            "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\n" +
                    "quis nostrud exercitation ullamco laboris nisi ut aliquip.",

            "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\n" +
                    "quis nostrud exercitation ullamco laboris nisi ut aliquip.",

            "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod"

    };

    @Override
    public int getCount() {
        return slideHeadings.length;
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == (RelativeLayout) object;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {

        layoutInflater = (LayoutInflater) mContext.getSystemService(mContext.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.slide_layout, container, false);

        ImageView slideImage = (ImageView) view.findViewById(R.id.SlideImage);
        TextView slideHeading = (TextView) view.findViewById(R.id.Slide_Heading);
        TextView slidedesc = (TextView) view.findViewById(R.id.Slide_Desc);

        slideImage.setImageResource(slideIamage[position]);
        slideHeading.setText(slideHeadings[position]);
        slidedesc.setText(slideDesc[position]);
        container.addView(view);
        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((RelativeLayout) object);
    }
}