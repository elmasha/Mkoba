package com.el.mkoba;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.os.Build;
import android.os.Bundle;
import android.text.TextPaint;
import android.view.View;
import android.widget.TextView;

public class PayMethodActivity extends AppCompatActivity {




    private TextView Mpesa,create_tab,pending_tab,past_tab,lable;
    private ViewPager viewPager;
    private PagerAdapter pagerAdapter;
    private View view1,view2,view3;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay_method);



        create_tab = findViewById(R.id.Create);
        pending_tab = findViewById(R.id.Pending);
        past_tab = findViewById(R.id.Past);
        viewPager = findViewById(R.id.ViewPager12);
        lable = findViewById(R.id.Label_pay);
        view1 = findViewById(R.id.linV1);
        view2 = findViewById(R.id.LinV2);
        view3 = findViewById(R.id.linV3);

        lable.setTextColor(getColor(R.color.colorPrimary));
        create_tab.setTextSize(18);


        pending_tab.setTextColor(getColor(R.color.colorGrey));
        pending_tab.setTextSize(14);

        past_tab.setTextColor(getColor(R.color.colorGrey));
        past_tab.setTextSize(13);

        pagerAdapter = new PagerAdapter(getSupportFragmentManager());
        viewPager.setAdapter(pagerAdapter);
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onPageSelected(int position) {

                Change(position);

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });



    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onStart() {
        super.onStart();

        create_tab.setTextSize(18);
        TextPaint paint = lable.getPaint();
        float width = paint.measureText("Create Payment");

        Shader textShader = new LinearGradient(0, 0, width, lable.getTextSize(),
                new int[]{
                        Color.parseColor("#14bfd9"),
                        Color.parseColor("#7658A5"),
                        Color.parseColor("#E930B5"),
                }, null, Shader.TileMode.CLAMP);
        create_tab.getPaint().setShader(textShader);
        view1.setVisibility(View.VISIBLE);





        pending_tab.setTextColor(getColor(R.color.colorGrey));
        pending_tab.setTextSize(14);

        past_tab.setTextColor(getColor(R.color.colorGrey));
        past_tab.setTextSize(14);

    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void Change(int position) {

        TextPaint paint = lable.getPaint();
        float width = paint.measureText("Create Payment");

        Shader textShader = new LinearGradient(0, 0, width, lable.getTextSize(),
                new int[]{
                        Color.parseColor("#14bfd9"),
                        Color.parseColor("#7658A5"),
                        Color.parseColor("#E930B5"),
                }, null, Shader.TileMode.CLAMP);

        TextPaint paint1 = lable.getPaint();
        float width1 = paint1.measureText("Create Payment");

        Shader textShader1 = new LinearGradient(0, 0, width, lable.getTextSize(),
                new int[]{
                        Color.parseColor("#808080"),
                        Color.parseColor("#808080"),
                        Color.parseColor("#808080"),
                }, null, Shader.TileMode.CLAMP);

        if (position ==0){

            TextPaint paint2 = create_tab.getPaint();
            float width2 = paint2.measureText("CreaPayment");

            Shader textShader2 = new LinearGradient(0, 0, width2, create_tab.getTextSize(),
                    new int[]{
                            Color.parseColor("#14bfd9"),
                            Color.parseColor("#7658A5"),
                            Color.parseColor("#E930B5"),
                    }, null, Shader.TileMode.CLAMP);

            create_tab.setTextSize(18);
            create_tab.getPaint().setShader(textShader2);
            view1.setVisibility(View.VISIBLE);
            view2.setVisibility(View.INVISIBLE);
            view3.setVisibility(View.INVISIBLE);

            pending_tab.getPaint().setShader(textShader1);
            pending_tab.setTextSize(14);

            past_tab.getPaint().setShader(textShader1);
            past_tab.setTextSize(14);


        }if (position == 1){
            create_tab.getPaint().setShader(textShader1);
            create_tab.setTextSize(14);


            pending_tab.setTextSize(18);
            pending_tab.getPaint().setShader(textShader);
            view1.setVisibility(View.INVISIBLE);
            view2.setVisibility(View.VISIBLE);
            view3.setVisibility(View.INVISIBLE);




            past_tab.getPaint().setShader(textShader1);
            past_tab.setTextSize(14);

        }if (position==2){

            create_tab.getPaint().setShader(textShader1);
            create_tab.setTextSize(14);


            pending_tab.getPaint().setShader(textShader1);
            pending_tab.setTextSize(14);

            past_tab.setTextSize(18);
            past_tab.getPaint().setShader(textShader);
            view1.setVisibility(View.INVISIBLE);
            view2.setVisibility(View.INVISIBLE);
            view3.setVisibility(View.VISIBLE);


        }


    }
}